import React from 'react';
import ProfileData from './ProfileData.js';
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';


function Reports() {

    return (


      <ProfileData />

    )

}

export default Reports
