import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from "axios";
import { useEffect } from 'react';
import CompletedTaskData from './CompletedTaskData.js';




const CreateTask = () => {

return(

    <CompletedTaskData/>
)

}



export default CreateTask;