import React from 'react'
import TaggerData from './TaggerData'

function Tagger() {
  return (
    <div>
      <h1>Welcome, Tagger</h1>
      <TaggerData />
      </div>
  )
}

export default Tagger
