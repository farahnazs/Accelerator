export const ROLES = Object.freeze({
    ADMIN: "Admin",
    TAGGER: "Tagger",
    REVIEWER: "Reviewer",
    MANAGER: "Manager",
  });