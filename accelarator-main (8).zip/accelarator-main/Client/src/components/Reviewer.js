import React from 'react'
import ReviewerData from './ReviewerData';
function Reviewer() {
  return (
    <div>
    <h1> Im a Revieweer </h1>
    <ReviewerData />
    </div>
  )
}

export default Reviewer
