import Dashboard from './components/Dashboard';
import React from 'react';
import './App.css';
const App = () => {
  return (
    <div>
      <Dashboard />
    </div>
  );
}

export default App;
