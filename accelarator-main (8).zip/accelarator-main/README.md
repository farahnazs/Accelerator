# accelarator
To start the server run - npm run server
